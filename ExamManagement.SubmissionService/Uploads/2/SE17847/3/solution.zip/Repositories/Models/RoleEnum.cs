﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public enum RoleEnum
    {
        administrator = 5,
        moderator = 6,
        developer = 7,
        member = 4
    }
}
