﻿namespace PE_2.API.Model.Handbag
{
    public class UpdateLeopardProfileRequest : LeopardProfileRequest
    {
    }
}
