﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Models
{
   public enum RoleEnum
    {
        Administrator = 5,
        Moderator = 6,
        Developer = 7,
        Member = 4
    }
}
